# Copilot M365 Agent 一键更新与配置指南

本压缩包已为你聚合好了更新 Copilot Agent 所需的所有核心资产：

## 1. 更新系统提示词 (Instructions)
1. 访问微软 Copilot 代理编辑页：https://m365.cloud.microsoft 或 Copilot Studio；
2. 找到你的专属 Agent（如以 `T_9feac605-5...` 结尾的 Agent）；
3. 打开「配置」或「说明 (Instructions)」编辑框；
4. 全选清空后，直接将本目录下的 `Instructions-系统提示词.txt` 全文复制并粘贴进去；
5. 点击右上角「保存 (Save)」或「更新 (Update)」。

## 2. 上传知识库 / 专属技能 (Knowledge & Skills)
1. 在 Agent 配置页面的「知识 (Knowledge)」或「功能 / 技能」板块；
2. 上传本目录下 `skills/` 目录中的技能文档（如 `skills/handoff/SKILL.md`）；
3. 保存生效。

完成上述更新后，在本地终端运行 `cph-pi <workspaceRoot>` 即可即刻体验最新的正向引导与 File-First 原生交接！
